
public class funcion {

	static int potencia(int x, int y){
		 int r,con,pot=0;
         con=x;
         
         for(int i=1;i<=y;i++) {
       	  r=0;
       	  for(int j=1;j<=x;j++) {
           	r=r+con;  
           	
           	  
           	  
             }
       	  pot=con;
       	  con=r;
       	  
         }
		
		
		
		
		return pot;
		
	}
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
         
		int num=potencia(2,4);
		 System.out.println(num);
		
	}

}
