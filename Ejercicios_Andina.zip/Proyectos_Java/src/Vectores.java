
public class Vectores {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] numeros= new int[3];
		
		int M=1;
		int N=1000;
		int aux;
		for (int i=0;i<3;i++) {
			numeros[i]=(int)(Math.random()*(N-M+1)+M);
			                  }
		
		
		
		
		
		 for(int i = 0; i < (3-1); i++){
		      
			 for(int j = 0; j < (3-1); j++){
                if( numeros[j] > numeros[j+1]) {
		        
                 aux=numeros[j] ;
                 numeros[j] =numeros[j+1] ;
                 numeros[j+1]=aux;		 
                }
		       
		        }
		
		 }
		 
		 for (int i=0;i<3;i++) {
				System.out.println(numeros[i]);

				                  }
		
		

	}

}
